"""
Kimeneti fájlok az Álomváros szimulátorhoz
""" 